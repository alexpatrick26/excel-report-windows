
import os
import pathlib

app_path = pathlib.Path(__file__).parent / "app.py"
os.system(f"streamlit run \"{app_path}\"")
