
import streamlit as st
import pandas as pd
import os

st.set_page_config(page_title="Excel Report Automation", layout="wide")
st.title("📊 Excel Report Automation Tool")
st.write("Upload your file (CSV, Excel, TXT, etc.) and generate a pivot table instantly.")

uploaded_file = st.file_uploader("Upload your file", type=["csv", "xls", "xlsx", "txt", "cls"])
df = None

if uploaded_file:
    file_name = uploaded_file.name
    file_ext = os.path.splitext(file_name)[1].lower()

    try:
        if file_ext == ".csv":
            try:
                df = pd.read_csv(uploaded_file)
            except UnicodeDecodeError:
                df = pd.read_csv(uploaded_file, encoding="ISO-8859-1")
        elif file_ext in [".xls", ".xlsx"]:
            df = pd.read_excel(uploaded_file)
        elif file_ext in [".txt", ".cls"]:
            try:
                df = pd.read_csv(uploaded_file, delimiter="\t")
            except:
                try:
                    df = pd.read_csv(uploaded_file, delimiter=",")
                except UnicodeDecodeError:
                    df = pd.read_csv(uploaded_file, delimiter=",", encoding="ISO-8859-1")
        else:
            st.error("Unsupported file format.")
        if df is None or df.empty or df.columns.size == 0:
            raise ValueError("No columns to parse. File might be empty or not formatted properly.")
    except Exception as e:
        st.error(f"❌ Error reading the file: {e}")
        df = None

if df is not None:
    df.dropna(how='all', inplace=True)
    df.columns = df.columns.astype(str).str.strip().str.lower().str.replace(' ', '_').str.replace('#', '', regex=False)
    df = df.loc[:, ~df.columns.str.contains('^unnamed', case=False)]
    st.subheader("🔍 Preview of Cleaned Data")
    st.dataframe(df.head())
    if len(df.columns) < 2:
        st.warning("Not enough usable columns for pivot table.")
    else:
        st.subheader("📌 Build Your Pivot Table")
        index_col = st.selectbox("Choose a row field (Index)", df.columns)
        value_col = st.selectbox("Choose a value field", df.columns)
        agg_func = st.selectbox("Choose an aggregation method", ['sum', 'mean', 'count'])
        if st.button("Generate Pivot Table"):
            try:
                pivot = pd.pivot_table(df, index=index_col, values=value_col, aggfunc=agg_func)
                st.success("✅ Pivot Table Generated!")
                st.dataframe(pivot)
                output_file = "automated_report.xlsx"
                pivot.to_excel(output_file)
                with open(output_file, "rb") as f:
                    st.download_button("📥 Download Pivot Report", f, file_name=output_file)
            except Exception as e:
                st.error(f"⚠️ Error creating pivot table: {e}")
